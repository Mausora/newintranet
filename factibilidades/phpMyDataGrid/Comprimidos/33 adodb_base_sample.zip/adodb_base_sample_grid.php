<?php
	#######################################################################################
	#######################################################################################
	#######################################################################################
	######                                                                           ######
	###### This sample DO NOT INCLUDE ADOdb files, you must download the library     ######
	###### Please download ADOdb Library from http://adodb.sourceforge.net/          ######
	######                                                                           ######
	###### Este ejemplo NO INCLUYE los archivos de la librer�a ADOdb                 ######
	###### Por favor descargue la libreria ADOdb desde http://adodb.sourceforge.net/ ######
	######                                                                           ######
	#######################################################################################
	#######################################################################################
	#######################################################################################

	#es: Incluir el archivo de la libreria
	#en: Include class file
	require_once('class/phpmydatagrid.class.php');	
	
	#es: Incluir la librer�a ADOdb - Leer nota al principio del ejemplo
	#es: Include ADOdb class - Read note at the top of this sample
	include_once("adodb/adodb.inc.php");

	#es: Algunas bases de datos como oracle o mssql requieren que se especifique el siguiente parametro
	#en: Some databases like oracle or mssql are required to specify the next parameter
    $ADODB_FETCH_MODE = ADODB_FETCH_BOTH; 

	#es: Crear el objeto contenedor
	#en: Create object container
	$objGrid = new datagrid('adodb_base_sample_grid.php','1');
	
	#es: Realizar la conexi�n con la base de datos, definiendo que se utilizar� ADODdb
	#en: Connect with database, defining which will be used ADOdb 
	$objGrid-> conectadb("127.0.0.1", "user", "password", "guru_sample_a", true, "mysql");
	
	#es: Cambiar el caracter de delimitacion de campos 
	#en: Change the delimiter character of the fields 
	$objGrid-> backtick = "`";
	
	#es: Especificar la tabla de trabajo
	#en: Define Tablename
	$objGrid-> tabla ("employee");
	
	#es: Definir campo llave
	#en: Define keyfield
	$objGrid-> keyfield ("emp_id");
	
	#es: Mostrar Boton de "Grabar y Nuevo"
	#en: Display "Save & New" Button
	$objGrid-> saveaddnew = true;

	#es: Visualizar la presentaci�n con barra de herramientas
	#en: Enable toolbar look
	$objGrid-> toolbar=true;
	
	#es: Definir un t�tulo para el grid
	#en: Define a Grid Title
	$objGrid-> tituloGrid("Company ABC, employees");
	
	#es: Generar un c�digo HTML amigable y legible
	#en: Generate an HTML code friendly and readable
	$objGrid-> friendlyHTML();
	
	#es: Definir acciones permitidas
	#en: Define allowed actions
	$objGrid-> buttons(true,true,true,true,0);
	
	#es: Especificar los campos a mostrar con sus respectivas caracter�sticas:
	#en: Specify each field to display with their own properties
	$objGrid-> FormatColumn("emp_id","ID", "40", "50", "1", "93", "left", "text");
	$objGrid-> FormatColumn("active","Status", "13", "1", 0, "60", "left", "check:Inactive:Active");
	$objGrid-> FormatColumn("fname","Name", "13", "20", 0, "95","left");
	$objGrid-> FormatColumn("minit","Middle Name", "5", "1", 0, "80", "left");
	$objGrid-> FormatColumn("lname","Last Name", "5", "30", 0, "95", "left");
	$objGrid-> FormatColumn("birth_date","Birth Date", "5", "10", "0", "105", "left", "date:ymd:-");

	#es: Presentar solo 5 registros por pagina
	#en: Show 5 records per page
	$objGrid-> datarows(5);

	#es: Definir campo(s) para b�squedas
	#en: Define search field(s)
	$objGrid-> searchby ("fname, lname");

	#es: Definir el tipo de paginacion
	#en: Define pagination mode
	$objGrid-> paginationmode ("input");

	#es: Por ultimo, renderizar el Grid
	#en: Finally, render the grid.
	$objGrid-> grid();
?>