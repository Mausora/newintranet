<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>phpMyDataGrid Sample</title>
<!-- Set page content as utf-8 -->
<!-- Definir que el contenido de la pagina es utf-8 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link type='text/css' rel='stylesheet' href='style.css' />
<?php 
	#es: esta es la forma RECOMENDADA de incluir los archivos auxiliares (CSS,JS)
	#en: this is the recommended way to include the auxiliary files (CSS,JS)
	include_once('class/phpmydatagrid.class.php'); 
	echo set_DG_Header("js/","css/", " /", "greenday");
?>
</head>

<body>
	<div id='ghead'>
    	<div id='glogo'>
			<a href="index.php">phpMyDataGrid Professional - Sample of use</a>
        </div>
    </div>
	<table border="0" id="bg">
	  <tr>
		<td id="content">
			<h2>Base Sample UTF-8</h2>
			<div id='descripcion'>
				Este ejemplo enseña a incluir un datagrid funcional que trabaja con caracteres internacionales (UTF-8)
			</div>
			<div id='description'>
				This sample teach how to include a datagrid working with utf-8 data
			</div>
			<div id='dg'> 
				<?php include_once("base_sample_utf8_grid.php"); ?>
			</div>
            <small><em>Important: Your databases and tables must have UTF-8 collatiion<br />
            Importante: Sus bases de datos y tablas deben estar marcadas como UTF-8</em></small>
		    <input type="button" onclick='location.href="../samples.php"' style="float:right;" value="&lt;--" />
		</td>
	  </tr>
	</table>
</body>
</html>