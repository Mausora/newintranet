<?php
	#es: Incluir el archivo de la libreria
	#en: Include class file
	require_once('class/phpmydatagrid.class.php');
	
	#es: Crear el objeto contenedor
	#en: Create object container
	$objGrid = new datagrid('base_sample_utf8_grid.php','1');
	
	#es: Realizar la conexi�n con la base de datos
	#en: Connect with database
	$objGrid-> conectadb("127.0.0.1", "user", "password", "guru_sample_a");

	#es: Si el idioma es chino, Definir que se trata de PDF en chino
	#en: If chinese, Define it is a chinese PDF
	$objGrid->chinesePDF = true;

	#es: Definir codificaci�n de las p�ginas como UTF-8
	#en: Define html datacoding as UTF-8
	$objGrid-> charset = 'UTF-8';
	
	#es: Definir codificaci�n de las tablas como UTF-8
	#en: Define tables datacoding as UTF-8
	$objGrid-> sqlcharset = 'utf8';
	
	#es: Especificar la tabla de trabajo
	#en: Define Tablename
	$objGrid-> tabla ("employee_utf8");
	
	#es: Definir campo llave
	#en: Define keyfield
	$objGrid-> keyfield ("emp_id");
	
	#es: Definir campo(s) para b�squedas
	#en: Define search field(s)
	$objGrid-> searchby ("fname, lname");
	
	#es: Definir acciones permitidas
	#en: Define allowed actions
	$objGrid-> buttons(true,true,true,true,0);
	
	#es: Definir opciones de exportacion
	#en: Define exporting options
	$objGrid-> export(true,true,true,true,true);
	
	#es: Especificar los campos a mostrar con sus respectivas caracter�sticas:
	#en: Specify each field to display with their own properties
	$objGrid-> FormatColumn("emp_id","ID", "40", "50", "1", "93", "left", "text");
	$objGrid-> FormatColumn("active","Status", "13", "1", 0, "60", "left", "check:Inactive:Active");
	$objGrid-> FormatColumn("fname","Name", "13", "20", 0, "95","left");
	$objGrid-> FormatColumn("minit","Middle Name", "5", "1", 0, "80", "left");
	$objGrid-> FormatColumn("lname","Last Name", "5", "30", 0, "95", "left");
	$objGrid-> FormatColumn("birth_date","Birth Date", "5", "10", "0", "105", "left", "date:ymd:-");
	
	#es: Permitir Edici�n AJAX online
	#en: Allow AJAX online edition
	$objGrid-> ajax('default');
	
	#es: Por ultimo, renderizar el Grid
	#en: Finally, render the grid.
	$objGrid-> grid();
?>